﻿const WEB_APP_URL = 'https://work-attendance-system-ashen.vercel.app/api/documents/import-area-pms';
const SMARTAREA_RECEIVE_URL = 'http://101.51.157.107/smartarea/index.php?option=book&task=main/receive';
const AUTO_ALARM = 'smartarea-auto-import';
const AUTO_START_DELAY_MINUTES = 2;
const AUTO_RECENT_RUN_GUARD_MINUTES = 15;
let autoImportRunning = false;
const FAST_SYNC_COOLDOWN_MS = 3 * 60 * 1000;
const FAST_SYNC_LAST_RUN_KEY = 'smartAreaFastSyncLastRun';

async function setImportStatus(status, message, extra = {}) {
  await chrome.storage.local.set({
    smartAreaImportStatus: {
      status,
      message,
      updatedAt: new Date().toISOString(),
      ...extra
    }
  });
}


async function getFastSyncCooldown(force = false) {
  if (force) return { blocked: false, remainingSeconds: 0 };

  const stored = await chrome.storage.local.get(FAST_SYNC_LAST_RUN_KEY);
  const lastRun = Number(stored[FAST_SYNC_LAST_RUN_KEY] || 0);
  const remainingMs = Math.max(
    0,
    FAST_SYNC_COOLDOWN_MS - (Date.now() - lastRun)
  );

  return {
    blocked: remainingMs > 0,
    remainingSeconds: Math.ceil(remainingMs / 1000)
  };
}

async function markFastSyncStarted() {
  await chrome.storage.local.set({
    [FAST_SYNC_LAST_RUN_KEY]: Date.now()
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message) return;

  if (message.type === 'SMARTAREA_POST_IMPORT_API') {
    postToImportApi(message.payload)
      .then(result => sendResponse({ ok: true, result }))
      .catch(error => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }

  if (message.type === 'SMARTAREA_IMPORT_PROGRESS') {
    setImportStatus('running', message.message || 'กำลังอัปเดตข้อมูล')
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }

  if (message.type === 'SMARTAREA_OPEN_SIGNER') {
    openSigner(message.payload)
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }

  if (message.type === 'SMARTAREA_AUTO_ENABLE') {
    enableAutoImport(message.startPage, message.intervalMinutes)
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }

  if (message.type === 'SMARTAREA_AUTO_DISABLE') {
    disableAutoImport()
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }

  if (message.type === 'SMARTAREA_CHECK_NOW') {
    const fullSync = Boolean(message.fullSync);
    const force = Boolean(message.force);

    (async () => {
      if (!fullSync) {
        const cooldown = await getFastSyncCooldown(force);

        if (cooldown.blocked) {
          return {
            ok: false,
            cooldown: true,
            remainingSeconds: cooldown.remainingSeconds,
            error: `เพิ่งอัปเดตไป กรุณารออีก ${cooldown.remainingSeconds} วินาที`
          };
        }

        await markFastSyncStarted();
      }

      const result = await runAutoImport(true, {
        startPage: Number(message.startPage || 0),
        fullSync,
        lookbackPages: fullSync ? 0 : 3
      });

      return { ok: true, result };
    })()
      .then(sendResponse)
      .catch(error =>
        sendResponse({
          ok: false,
          error: error.message || String(error)
        })
      );

    return true;
  }

  if (message.type === 'SMARTAREA_GET_IMPORT_PLAN') {
    getImportScanPlan()
      .then(result => sendResponse({ ok: true, result }))
      .catch(error => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }
});

async function openSigner(payload) {
  const params = new URLSearchParams();
  Object.entries(payload || {}).forEach(([key, value]) => params.set(key, String(value || '')));
  await chrome.tabs.create({ url: chrome.runtime.getURL(`sign.html?${params.toString()}`), active: true });
}

async function updateStoredNextRun() {
  const alarm = await chrome.alarms.get(AUTO_ALARM);

  await chrome.storage.local.set({
    smartAreaAutoNextRun:
      alarm && alarm.scheduledTime
        ? new Date(alarm.scheduledTime).toISOString()
        : ''
  });
}

async function scheduleAutoAlarm(intervalMinutes, initialDelayMinutes) {
  const interval = Math.max(Number(intervalMinutes || 60), 60);
  const initialDelay = Math.max(
    Number(initialDelayMinutes || AUTO_START_DELAY_MINUTES),
    1
  );

  await chrome.alarms.clear(AUTO_ALARM);
  chrome.alarms.create(AUTO_ALARM, {
    delayInMinutes: initialDelay,
    periodInMinutes: interval
  });
  await updateStoredNextRun();
}

async function wasCheckedRecently() {
  const { smartAreaAutoLastRun } = await chrome.storage.local.get([
    'smartAreaAutoLastRun'
  ]);

  if (!smartAreaAutoLastRun) return false;

  const lastRunTime = new Date(smartAreaAutoLastRun).getTime();
  if (Number.isNaN(lastRunTime)) return false;

  return (
    Date.now() - lastRunTime <
    AUTO_RECENT_RUN_GUARD_MINUTES * 60 * 1000
  );
}

chrome.alarms.onAlarm.addListener(async alarm => {
  if (alarm.name !== AUTO_ALARM) return;

  const { smartAreaAutoImport } = await chrome.storage.local.get([
    'smartAreaAutoImport'
  ]);

  if (!smartAreaAutoImport || smartAreaAutoImport.enabled !== true) {
    await chrome.alarms.clear(AUTO_ALARM);
    await chrome.storage.local.set({ smartAreaAutoNextRun: '' });
    return;
  }

  if (await wasCheckedRecently()) {
    await setImportStatus(
      'idle',
      `ข้ามการตรวจซ้ำ เพราะตรวจล่าสุดยังไม่เกิน ${AUTO_RECENT_RUN_GUARD_MINUTES} นาที`
    );
    await updateStoredNextRun();
    return;
  }

  runAutoImport(false).catch(error => console.warn(error));
});

chrome.runtime.onStartup.addListener(() => restoreAutoAlarm());
chrome.runtime.onInstalled.addListener(() => restoreAutoAlarm());

async function enableAutoImport(startPage, intervalMinutes) {
  const credentials = await chrome.storage.local.get([
    'smartAreaUsername',
    'smartAreaPassword'
  ]);

  if (!credentials.smartAreaUsername || !credentials.smartAreaPassword) {
    throw new Error('กรุณาบันทึกชื่อผู้ใช้และรหัสผ่าน Smart Area ก่อน');
  }

  const config = {
    enabled: true,
    intervalMinutes: Math.max(Number(intervalMinutes || 60), 60),
    startupDelayMinutes: AUTO_START_DELAY_MINUTES,
    recentRunGuardMinutes: AUTO_RECENT_RUN_GUARD_MINUTES
  };

  await chrome.storage.local.set({ smartAreaAutoImport: config });
  await scheduleAutoAlarm(
    config.intervalMinutes,
    config.startupDelayMinutes
  );
  await setImportStatus(
    'idle',
    `เปิดตรวจอัตโนมัติแล้ว จะตรวจครั้งแรกใน ${AUTO_START_DELAY_MINUTES} นาที`
  );
}

async function disableAutoImport() {
  await chrome.storage.local.set({ smartAreaAutoImport: { enabled: false }, smartAreaAutoNextRun: '' });
  await chrome.alarms.clear(AUTO_ALARM);
}

async function restoreAutoAlarm() {
  const { smartAreaAutoImport, smartAreaUsername, smartAreaPassword } =
    await chrome.storage.local.get([
      'smartAreaAutoImport',
      'smartAreaUsername',
      'smartAreaPassword'
    ]);

  await chrome.alarms.clear(AUTO_ALARM);

  const enabled = Boolean(
    smartAreaAutoImport &&
    smartAreaAutoImport.enabled === true &&
    smartAreaUsername &&
    smartAreaPassword
  );

  if (!enabled) {
    await chrome.storage.local.set({
      smartAreaAutoImport: {
        enabled: false,
        intervalMinutes: Math.max(
          Number(
            (smartAreaAutoImport && smartAreaAutoImport.intervalMinutes) || 60
          ),
          60
        )
      },
      smartAreaAutoNextRun: ''
    });
    return;
  }

  const restoredConfig = {
    enabled: true,
    intervalMinutes: Math.max(
      Number(
        (smartAreaAutoImport && smartAreaAutoImport.intervalMinutes) || 60
      ),
      60
    ),
    startupDelayMinutes: AUTO_START_DELAY_MINUTES,
    recentRunGuardMinutes: AUTO_RECENT_RUN_GUARD_MINUTES
  };

  await chrome.storage.local.set({
    smartAreaAutoImport: restoredConfig
  });
  await scheduleAutoAlarm(
    restoredConfig.intervalMinutes,
    restoredConfig.startupDelayMinutes
  );
  await setImportStatus(
    'idle',
    `เปิด Chrome แล้ว ระบบจะตรวจอัตโนมัติใน ${AUTO_START_DELAY_MINUTES} นาที`
  );
}

async function runAutoImport(manualRun = false, options = {}) {
  if (autoImportRunning) {
    await setImportStatus('running', 'กำลังดึงข้อมูลอยู่แล้ว กรุณารอสักครู่');
    return { alreadyRunning: true };
  }
  autoImportRunning = true;
  let createdTabId = null;

  try {
    await setImportStatus('running', manualRun ? 'กำลังอัปเดตล่าสุดตามคำสั่ง' : 'กำลังตรวจหนังสืออัตโนมัติ');
    const { smartAreaUsername, smartAreaPassword } = await chrome.storage.local.get([
      'smartAreaUsername',
      'smartAreaPassword'
    ]);
    if (!manualRun && (!smartAreaUsername || !smartAreaPassword)) return;

    await setImportStatus('running', 'กำลังเปิดหน้าหนังสือรับ Smart Area');
    const tabs = await chrome.tabs.query({ url: 'http://101.51.157.107/smartarea/*' });
    let tab = tabs.find(item => String(item.url || '').includes('task=main/receive'));
    if (!tab) {
      tab = await chrome.tabs.create({ url: SMARTAREA_RECEIVE_URL, active: false });
      createdTabId = tab.id;
    } else if (tab.url !== SMARTAREA_RECEIVE_URL) {
      tab = await chrome.tabs.update(tab.id, { url: SMARTAREA_RECEIVE_URL, active: false });
    }

    await waitForTabComplete(tab.id, 30000);
    await setImportStatus('running', 'กำลังตรวจสอบการเข้าสู่ระบบ Smart Area');
    const loginResult = await sendTabMessage(tab.id, {
      type: 'SMARTAREA_FILL_LOGIN',
      forceSubmit: true
    }).catch(() => null);
    if (loginResult && loginResult.submitted) {
      await setImportStatus('running', 'กำลังเข้าสู่ระบบ Smart Area');
      await sleep(4000);
      await chrome.tabs.update(tab.id, { url: SMARTAREA_RECEIVE_URL, active: false });
      await waitForTabComplete(tab.id, 30000);
    }

    const fullSyncStartPage = Number(options.startPage || 0);
    await setImportStatus(
      'running',
      fullSyncStartPage
        ? `กำลังตรวจย้อนหลังตั้งแต่หน้า ${fullSyncStartPage} ถึงหน้าปัจจุบัน`
        : 'กำลังตรวจหน้าล่าสุดและนำเข้ารายการใหม่'
    );

    const importMessage = fullSyncStartPage
      ? {
          type: 'SMARTAREA_IMPORT_FROM_PAGE',
          startPage: fullSyncStartPage,
          silent: true,
          strictPageCoverage: true
        }
      : {
          type: 'SMARTAREA_IMPORT_PAGE',
          silent: true,
          strictPageCoverage: true,
          lookbackPages: Number(options.lookbackPages || 3)
        };

    const timeoutMs = fullSyncStartPage ? 3600000 : 300000;
    const timeoutMessage = fullSyncStartPage
      ? 'การตรวจเทียบทั้งระบบใช้เวลานานเกิน 60 นาที กรุณาเปิดหน้า Smart Area ค้างไว้แล้วลองใหม่'
      : 'ใช้เวลานำเข้านานเกิน 5 นาที กรุณาลองใหม่อีกครั้ง';

    const result = await withTimeout(
      sendTabMessage(tab.id, importMessage),
      timeoutMs,
      timeoutMessage
    );
    const summary = result && result.result
      ? `สแกนหน้า ${result.result.scanStartPage}-${result.result.scanEndPage}, พบ ${result.result.totalFound}, เพิ่มใหม่ ${result.result.addedCount}, อัปเดต ${result.result.updatedCount || 0}, ไม่เปลี่ยน ${result.result.unchangedCount || 0}, ผิดพลาด ${result.result.errorCount}`
      : '';
    await chrome.storage.local.set({
      smartAreaAutoLastRun: new Date().toISOString(),
      smartAreaAutoLastResult: result && result.ok ? 'สำเร็จ' : 'ไม่สำเร็จ'
    });
    if (result && result.ok && summary) {
      await chrome.storage.local.set({ smartAreaAutoLastResult: summary });
      await setImportStatus('done', summary, { result: result.result || null });
      return { ok: true, result: result.result || null };
    } else {
      await setImportStatus('done', 'ตรวจเสร็จแล้ว แต่ไม่มีสรุปผลจากระบบ');
      return { ok: true, result: result && result.result || null };
    }
  } catch (error) {
    await setImportStatus('error', error.message || String(error));
    await chrome.storage.local.set({
      smartAreaAutoLastRun: new Date().toISOString(),
      smartAreaAutoLastResult: error.message || String(error)
    });
    console.warn(error);
    throw error;
  } finally {
    if (createdTabId) {
      try {
        await chrome.tabs.remove(createdTabId);
      } catch (error) {
        // The user may have already closed the temporary tab.
      }
    }
    const { smartAreaAutoImport } = await chrome.storage.local.get([
      'smartAreaAutoImport'
    ]);

    if (smartAreaAutoImport && smartAreaAutoImport.enabled === true) {
      await updateStoredNextRun();
    } else {
      await chrome.storage.local.set({ smartAreaAutoNextRun: '' });
    }

    autoImportRunning = false;
  }
}

async function getImportScanPlan() {
  const url = `${WEB_APP_URL}?action=getImportScanPlan&lookbackPages=3`;
  const response = await fetch(url);
  const text = await response.text();
  try {
    return JSON.parse(text);
  } catch (error) {
    return { ok: response.ok, message: text };
  }
}

function waitForTabComplete(tabId, timeoutMs) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error('Smart Area page load timed out'));
    }, timeoutMs);
    const listener = (updatedTabId, changeInfo) => {
      if (updatedTabId !== tabId || changeInfo.status !== 'complete') return;
      clearTimeout(timeout);
      chrome.tabs.onUpdated.removeListener(listener);
      setTimeout(resolve, 800);
    };
    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.get(tabId).then(tab => {
      if (tab.status === 'complete') {
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(listener);
        setTimeout(resolve, 800);
      }
    }).catch(reject);
  });
}

function sendTabMessage(tabId, message) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, message, response => {
      if (chrome.runtime.lastError) {
        chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] }, () => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          chrome.tabs.sendMessage(tabId, message, retryResponse => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
              return;
            }
            if (!retryResponse || !retryResponse.ok) {
              reject(new Error((retryResponse && (retryResponse.error || retryResponse.message)) || 'Smart Area command failed'));
              return;
            }
            resolve(retryResponse);
          });
        });
        return;
      }
      if (!response || !response.ok) {
        reject(new Error((response && (response.error || response.message)) || 'Smart Area command failed'));
        return;
      }
      resolve(response);
    });
  });
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function postToImportApi(payload) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30000);
  try {
    const response = await fetch(WEB_APP_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json;charset=utf-8'
      },
      body: JSON.stringify(payload),
      signal: controller.signal
    });

    const text = await response.text();
    try {
      return JSON.parse(text);
    } catch (error) {
      return {
        ok: response.ok,
        message: text
      };
    }
  } finally {
    clearTimeout(timeout);
  }
}

function withTimeout(promise, timeoutMs, message) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error(message)), timeoutMs);
    promise
      .then(resolve)
      .catch(reject)
      .finally(() => clearTimeout(timeout));
  });
}

