﻿(function () {
  const RESULT_TYPE = 'SMARTAREA_RUN_EXTENSION_IMPORT_RESULT';

  window.postMessage({
    type: 'SMARTAREA_EXTENSION_READY',
    version: chrome.runtime.getManifest().version
  }, '*');

  window.addEventListener('message', event => {
    if (event.source !== window || !event.data || event.data.type !== 'SMARTAREA_RUN_EXTENSION_IMPORT') return;

    const requestId = event.data.requestId || '';
    const payload = event.data.payload || {};

    chrome.runtime.sendMessage({
      type: 'SMARTAREA_CHECK_NOW',
      force: payload.force !== false,
      fullSync: Boolean(payload.fullSync),
      startPage: Number(payload.startPage || 0)
    }, response => {
      const runtimeError = chrome.runtime.lastError && chrome.runtime.lastError.message;
      window.postMessage({
        type: RESULT_TYPE,
        requestId,
        ok: Boolean(!runtimeError && response && response.ok),
        error: runtimeError || (response && response.error) || ''
      }, '*');
    });
  });
})();
