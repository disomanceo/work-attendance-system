﻿import * as pdfjsLib from './vendor/pdf.min.mjs';
import { PDFDocument } from './vendor/pdf-lib.esm.min.js';

pdfjsLib.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('vendor/pdf.worker.min.mjs');

const params = new URLSearchParams(location.search);
const signContext = {
  sourceUrl: cleanUrl(params.get('url')),
  fileName: params.get('fileName') || 'ไฟล์แนบ',
  subject: params.get('subject') || '',
  smartAreaId: params.get('smartAreaId') || '',
  documentNo: params.get('documentNo') || '',
  receiveNo: params.get('receiveNo') || '',
  bookRow: params.get('bookRow') || ''
};
const page = document.getElementById('page');
const canvas = document.getElementById('canvas');
const context = canvas.getContext('2d');
const empty = document.getElementById('empty');
let sourcePdfBytes = null;
let ready = false;
let selected = null;
let signatureData = localStorage.getItem('smartAreaExtensionSignature') || '';

document.getElementById('subject').textContent = signContext.subject || '-';
document.getElementById('fileName').textContent = signContext.fileName;
document.getElementById('openOriginal').href = signContext.sourceUrl || '#';
document.getElementById('chooseDocument').addEventListener('click', () => document.getElementById('documentFile').click());
document.getElementById('documentFile').addEventListener('change', event => loadLocalPdf(event.target.files[0]));
document.getElementById('changeSignature').addEventListener('click', () => document.getElementById('signatureFile').click());
document.getElementById('signatureFile').addEventListener('change', event => readSignature(event.target.files[0]));
document.getElementById('addSignature').addEventListener('click', addSignature);
document.getElementById('addText').addEventListener('click', addText);
document.getElementById('textDown').addEventListener('click', () => changeTextSize(-2));
document.getElementById('textUp').addEventListener('click', () => changeTextSize(2));
document.getElementById('remove').addEventListener('click', removeSelected);
document.getElementById('saveOnly').addEventListener('click', () => save(false));
document.getElementById('saveAssign').addEventListener('click', () => save(true));
updateSignatureUi();
loadSigningContext();

async function loadLocalPdf(file) {
  if (!file) return;
  const status = document.getElementById('loadStatus');
  clearSigningPage();
  ready = false;
  setReadyButtons(false);
  document.getElementById('fileStatus').textContent = 'กำลังเปิดไฟล์ที่เลือก...';
  status.textContent = 'กำลังสร้าง Preview จากไฟล์ในเครื่อง...';
  try {
    const bytes = new Uint8Array(await file.arrayBuffer());
    if (!bytes.length) throw new Error('ไฟล์ว่างเปล่า');
    if (bytes.length > 25 * 1024 * 1024) throw new Error('ไฟล์มีขนาดเกิน 25 MB');
    const header = String.fromCharCode(...bytes.subarray(0, 5));
    if (header !== '%PDF-') throw new Error('กรุณาเลือกไฟล์ PDF');
    sourcePdfBytes = bytes.slice();
    const pdf = await pdfjsLib.getDocument({ data: bytes.slice() }).promise;
    const pdfPage = await pdf.getPage(1);
    const viewport = pdfPage.getViewport({ scale: 1.3 });
    canvas.width = viewport.width;
    canvas.height = viewport.height;
    await pdfPage.render({ canvasContext: context, viewport }).promise;
    page.style.minHeight = '0';
    empty.hidden = true;
    ready = true;
    setReadyButtons(true);
    updateSignatureUi();
    document.getElementById('fileName').textContent = file.name;
    status.textContent = `พร้อมลงนาม: ${file.name} · ${formatBytes(bytes.length)} · ${pdf.numPages} หน้า`;
    document.getElementById('fileStatus').textContent = 'พร้อมบันทึก';
  } catch (error) {
    ready = false;
    setReadyButtons(false);
    status.textContent = error.message || String(error);
    document.getElementById('fileStatus').textContent = 'เปิดไฟล์ไม่สำเร็จ';
  }
}

function clearSigningPage() {
  document.querySelectorAll('.overlay').forEach(item => item.remove());
  selected = null;
  context.clearRect(0, 0, canvas.width, canvas.height);
  empty.hidden = false;
  empty.textContent = 'กำลังเปิดไฟล์ PDF ที่เลือก...';
  document.getElementById('remove').disabled = true;
  document.getElementById('textDown').disabled = true;
  document.getElementById('textUp').disabled = true;
}

async function loadSigningContext() {
  try {
    const result = await postToWorkAttendanceApi({ action: 'getSigningContext', bookRow: signContext.bookRow });
    renderOwners(result.owners || []);
  } catch (error) {
    document.getElementById('owners').textContent = 'โหลดรายชื่อไม่สำเร็จ';
  }
}

function renderOwners(owners) {
  const container = document.getElementById('owners');
  container.innerHTML = owners.length
    ? owners.map(name => `<label><input type="checkbox" value="${escapeAttr(name)}"><span>${escapeHtml(name)}</span></label>`).join('')
    : 'ยังไม่มีรายชื่อครู';
  container.querySelectorAll('input').forEach(input => input.addEventListener('change', refreshPrimary));
  refreshPrimary();
}

function refreshPrimary() {
  const names = selectedOwners();
  const current = document.getElementById('primaryOwner').value;
  document.getElementById('primaryOwner').innerHTML = names
    .map(name => `<option ${name === current ? 'selected' : ''}>${escapeHtml(name)}</option>`).join('');
}

function selectedOwners() {
  return [...document.querySelectorAll('#owners input:checked')].map(input => input.value);
}

async function readSignature(file) {
  if (!file) return;
  signatureData = await fileData(file);
  localStorage.setItem('smartAreaExtensionSignature', signatureData);
  updateSignatureUi();
}

function updateSignatureUi() {
  const preview = document.getElementById('signaturePreview');
  preview.hidden = !signatureData;
  if (signatureData) preview.src = signatureData;
  document.getElementById('addSignature').disabled = !ready || !signatureData;
  document.getElementById('addSignature').textContent = signatureData ? '✓ ใช้ลายเซ็นเดิม' : 'ยังไม่มีลายเซ็น';
}

function setReadyButtons(value) {
  document.getElementById('addText').disabled = !value;
  document.getElementById('addSignature').disabled = !value || !signatureData;
  document.getElementById('saveOnly').disabled = !value;
  document.getElementById('saveAssign').disabled = !value;
}

function addSignature() {
  if (!signatureData || !ready) return;
  const overlay = createOverlay('signature', 61, 55, 25, 11);
  overlay.innerHTML = `<img alt="ลายเซ็น" src="${signatureData}"><i class="resize"></i>`;
  bindOverlay(overlay);
}

function addText() {
  if (!ready) return;
  const text = document.getElementById('directive').value.trim();
  if (!text) return;
  const overlay = createOverlay('text', 58, 35, 35, 13);
  overlay.classList.add('text');
  overlay.dataset.fontSize = '14';
  overlay.style.fontSize = '14px';
  overlay.innerHTML = `${escapeHtml(`${text}\n${thaiDate()}`).replace(/\n/g, '<br>')}<i class="resize"></i>`;
  bindOverlay(overlay);
}

function createOverlay(type, x, y, width, height) {
  const overlay = document.createElement('div');
  overlay.className = 'overlay';
  overlay.dataset.type = type;
  setBox(overlay, x, y, width, height);
  page.appendChild(overlay);
  selectOverlay(overlay);
  return overlay;
}

function bindOverlay(overlay) {
  overlay.addEventListener('pointerdown', event => {
    selectOverlay(overlay);
    const resizing = event.target.classList.contains('resize');
    const box = getBox(overlay);
    const startX = event.clientX;
    const startY = event.clientY;
    const move = moveEvent => {
      const dx = (moveEvent.clientX - startX) / page.clientWidth * 100;
      const dy = (moveEvent.clientY - startY) / page.clientHeight * 100;
      if (resizing) setBox(overlay, box.x, box.y, Math.max(7, box.w + dx), Math.max(4, box.h + dy));
      else setBox(overlay, box.x + dx, box.y + dy, box.w, box.h);
    };
    const stop = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', stop);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', stop);
  });
}

function selectOverlay(overlay) {
  document.querySelectorAll('.overlay').forEach(item => item.classList.remove('selected'));
  selected = overlay;
  if (selected) selected.classList.add('selected');
  const isText = Boolean(selected && selected.dataset.type === 'text');
  document.getElementById('remove').disabled = !selected;
  document.getElementById('textDown').disabled = !isText;
  document.getElementById('textUp').disabled = !isText;
  document.getElementById('textSize').textContent = isText ? `${selected.dataset.fontSize || 14} px` : '14 px';
}

function changeTextSize(amount) {
  if (!selected || selected.dataset.type !== 'text') return;
  const size = Math.max(8, Math.min(72, Number(selected.dataset.fontSize || 14) + amount));
  selected.dataset.fontSize = String(size);
  selected.style.fontSize = `${size}px`;
  document.getElementById('textSize').textContent = `${size} px`;
}

function removeSelected() {
  if (selected) selected.remove();
  selected = null;
  document.getElementById('remove').disabled = true;
  document.getElementById('textDown').disabled = true;
  document.getElementById('textUp').disabled = true;
}

async function save(withAssignment) {
  if (!ready) return;
  const assignees = selectedOwners();
  if (withAssignment && !assignees.length) return setSaveStatus('กรุณาเลือกผู้รับผิดชอบอย่างน้อย 1 คน');
  setSaving(true, withAssignment ? 'กำลังบันทึกและมอบหมาย...' : 'กำลังบันทึก...');
  try {
    const dataUrl = await renderSignedPdf();
    const result = await postToWorkAttendanceApi({
      action: withAssignment ? 'saveSignedAndAssign' : 'saveSignedDocument',
      dataUrl,
      fileName: signContext.fileName,
      subject: signContext.subject,
      smartAreaId: signContext.smartAreaId,
      documentNo: signContext.documentNo,
      receiveNo: signContext.receiveNo,
      bookRow: signContext.bookRow,
      assignees,
      primary: document.getElementById('primaryOwner').value,
      directive: document.getElementById('directive').value,
      dueDate: document.getElementById('dueDate').value
    });
    const signed = result.signed || result;
    setSaveStatus(`บันทึกแล้ว: ${signed.name || 'ฉบับลงนาม'}`, signed.url);
    if (withAssignment) alert('บันทึกฉบับลงนามและมอบหมายงานเรียบร้อยแล้ว');
  } catch (error) {
    setSaveStatus(`บันทึกไม่สำเร็จ: ${error.message || error}`);
  } finally {
    setSaving(false);
  }
}

async function renderSignedPdf() {
  const imageData = await renderSignedPageImage();
  const outputPdf = await PDFDocument.create();
  const signedImage = await outputPdf.embedPng(dataUrlBytes(imageData));
  const sourcePdf = await PDFDocument.load(sourcePdfBytes);
  const firstSize = sourcePdf.getPage(0).getSize();
  const first = outputPdf.addPage([firstSize.width, firstSize.height]);
  first.drawImage(signedImage, { x: 0, y: 0, width: firstSize.width, height: firstSize.height });
  if (sourcePdf.getPageCount() > 1) {
    const indexes = Array.from({ length: sourcePdf.getPageCount() - 1 }, (_, index) => index + 1);
    const pages = await outputPdf.copyPages(sourcePdf, indexes);
    pages.forEach(pdfPage => outputPdf.addPage(pdfPage));
  }
  return bytesDataUrl(await outputPdf.save(), 'application/pdf');
}

async function renderSignedPageImage() {
  const output = document.createElement('canvas');
  output.width = canvas.width;
  output.height = canvas.height;
  const outputContext = output.getContext('2d');
  outputContext.drawImage(canvas, 0, 0);
  const scale = canvas.width / page.clientWidth;
  for (const overlay of document.querySelectorAll('.overlay')) {
    const box = getBox(overlay);
    const x = box.x / 100 * canvas.width;
    const y = box.y / 100 * canvas.height;
    const width = box.w / 100 * canvas.width;
    const height = box.h / 100 * canvas.height;
    if (overlay.dataset.type === 'signature') {
      outputContext.drawImage(overlay.querySelector('img'), x, y, width, height);
    } else {
      const fontSize = Number(overlay.dataset.fontSize || 14) * scale;
      outputContext.fillStyle = '#154c9c';
      outputContext.font = `700 ${fontSize}px Arial, sans-serif`;
      outputContext.textBaseline = 'top';
      overlay.innerText.split(/\n/).filter(Boolean).forEach((line, index) => {
        outputContext.fillText(line, x + 6 * scale, y + (6 + index * (fontSize / scale + 4)) * scale, width - 12 * scale);
      });
    }
  }
  return output.toDataURL('image/png');
}

function postToWorkAttendanceApi(payload) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type: 'SMARTAREA_POST_IMPORT_API', payload }, response => {
      const error = chrome.runtime.lastError && chrome.runtime.lastError.message;
      if (error || !response || !response.ok) return reject(new Error(error || response && response.error || 'เชื่อมต่อระบบโรงเรียนไม่สำเร็จ'));
      const result = response.result || {};
      if (result.ok === false) return reject(new Error(result.message || 'ดำเนินการไม่สำเร็จ'));
      resolve(result);
    });
  });
}

function setSaving(saving, text) {
  document.getElementById('saveOnly').disabled = saving || !ready;
  document.getElementById('saveAssign').disabled = saving || !ready;
  if (text) setSaveStatus(text);
}
function setSaveStatus(text, url) {
  const status = document.getElementById('saveStatus');
  status.textContent = text;
  if (url) {
    const link = document.createElement('a');
    link.href = url; link.target = '_blank'; link.textContent = ' เปิดไฟล์';
    status.appendChild(link);
  }
}
function setBox(element,x,y,w,h){const sw=Math.min(100,w),sh=Math.min(100,h);element.style.left=`${Math.max(0,Math.min(100-sw,x))}%`;element.style.top=`${Math.max(0,Math.min(100-sh,y))}%`;element.style.width=`${sw}%`;element.style.height=`${sh}%`}
function getBox(element){return{x:parseFloat(element.style.left),y:parseFloat(element.style.top),w:parseFloat(element.style.width),h:parseFloat(element.style.height)}}
function thaiDate(){return new Intl.DateTimeFormat('th-TH',{day:'numeric',month:'long',year:'numeric'}).format(new Date())}
function cleanUrl(value){return String(value||'').replace(/\/n\d*\.?$/i,'').trim()}
function formatBytes(value){return value<1048576?`${Math.round(value/1024)} KB`:`${(value/1048576).toFixed(1)} MB`}
function fileData(file){return new Promise(resolve=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.readAsDataURL(file)})}
function dataUrlBytes(value){const binary=atob(String(value).split(',')[1]||'');return Uint8Array.from(binary,char=>char.charCodeAt(0))}
function bytesDataUrl(bytes,mime){let binary='';for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,i+0x8000));return`data:${mime};base64,${btoa(binary)}`}
function escapeHtml(value){const div=document.createElement('div');div.textContent=String(value||'');return div.innerHTML}
function escapeAttr(value){return escapeHtml(value).replace(/"/g,'&quot;')}

