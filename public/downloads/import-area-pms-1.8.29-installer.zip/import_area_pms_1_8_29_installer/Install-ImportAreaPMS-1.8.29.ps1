﻿param(
  [string]$ProjectPath = "D:\work-attendance-system",
  [string]$ExtensionTarget = "",
  [string]$WorkAppBaseUrl = "https://work-attendance-system-beige.vercel.app",
  [switch]$SkipApiPatch
)

$ErrorActionPreference = "Stop"
$Version = "1.8.29"
$RecentLookbackPages = 3
$FullReconcileStartPage = 155

function Get-NewLine([string]$Text) {
  if ($Text -match "`r`n") { return "`r`n" }
  return "`n"
}

function Read-TextFile([string]$Path) {
  if (-not (Test-Path -LiteralPath $Path)) { throw "File not found: $Path" }
  return [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8)
}

function Write-TextFileUtf8Bom([string]$Path, [string]$Text) {
  $encoding = New-Object System.Text.UTF8Encoding($true)
  [System.IO.File]::WriteAllText($Path, $Text, $encoding)
}

function Replace-RegexOnce([string]$Path, [string]$Pattern, [string]$Replacement, [string]$Label) {
  $text = Read-TextFile $Path
  if (-not [regex]::IsMatch($text, $Pattern, [System.Text.RegularExpressions.RegexOptions]::Singleline)) {
    throw "Pattern not found for $Label in $Path"
  }
  $updated = [regex]::Replace($text, $Pattern, $Replacement, [System.Text.RegularExpressions.RegexOptions]::Singleline)
  if ($updated -ne $text) { Write-TextFileUtf8Bom $Path $updated }
}

function Ensure-RegexBlock([string]$Path, [string]$StartMarker, [string]$EndMarker, [string]$Block, [string]$BeforePattern, [string]$Label) {
  $text = Read-TextFile $Path
  $newline = Get-NewLine $text
  $pattern = [regex]::Escape($StartMarker) + "[\s\S]*?" + [regex]::Escape($EndMarker)
  $normalizedBlock = $Block -replace "`r?`n", $newline
  if ([regex]::IsMatch($text, $pattern)) {
    $updated = [regex]::Replace($text, $pattern, [System.Text.RegularExpressions.MatchEvaluator]{ param($m) $normalizedBlock })
  } else {
    if (-not [regex]::IsMatch($text, $BeforePattern, [System.Text.RegularExpressions.RegexOptions]::Singleline)) {
      throw "Insert location not found for $Label in $Path"
    }
    $updated = [regex]::Replace($text, $BeforePattern, [System.Text.RegularExpressions.MatchEvaluator]{ param($m) $normalizedBlock + $newline + $m.Value }, [System.Text.RegularExpressions.RegexOptions]::Singleline)
  }
  if ($updated -ne $text) { Write-TextFileUtf8Bom $Path $updated }
}

function Assert-SafeExtensionTarget([string]$Path) {
  $leaf = Split-Path -Leaf $Path
  if ($leaf -ne "import-area-pms-extension") {
    throw "Unsafe extension target. The target folder must be named import-area-pms-extension: $Path"
  }
}

function Reset-ExtensionTarget([string]$Destination) {
  Assert-SafeExtensionTarget $Destination
  if (Test-Path -LiteralPath $Destination) {
    Get-ChildItem -LiteralPath $Destination -Force | Remove-Item -Recurse -Force
  } else {
    New-Item -ItemType Directory -Path $Destination | Out-Null
  }
}

function Copy-DirectoryContent([string]$Source, [string]$Destination) {
  if (-not (Test-Path -LiteralPath $Source)) { throw "Source directory not found: $Source" }
  Reset-ExtensionTarget $Destination
  Get-ChildItem -LiteralPath $Source -Recurse -File | ForEach-Object {
    $relative = $_.FullName.Substring($Source.Length)
    $relative = $relative -replace '^[\\/]+', ''
    $target = Join-Path $Destination $relative
    $parent = Split-Path -Parent $target
    if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent | Out-Null }
    Copy-Item -LiteralPath $_.FullName -Destination $target -Force
  }
}

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$SourceExtension = Join-Path $ScriptRoot "extension"
if ([string]::IsNullOrWhiteSpace($ExtensionTarget)) {
  $ExtensionTarget = Join-Path $ProjectPath "tools\import-area-pms-extension"
}

$ApiUrl = $WorkAppBaseUrl.TrimEnd('/') + "/api/documents/import-area-pms"
$DocumentsUrl = $WorkAppBaseUrl.TrimEnd('/') + "/documents"

Write-Host "Installing Import Area PMS $Version"
Write-Host "Project path: $ProjectPath"
Write-Host "Extension target: $ExtensionTarget"
Write-Host "Import API: $ApiUrl"

Copy-DirectoryContent $SourceExtension $ExtensionTarget

$background = Join-Path $ExtensionTarget "background.js"
$content = Join-Path $ExtensionTarget "content.js"
$popupJs = Join-Path $ExtensionTarget "popup.js"
$popupHtml = Join-Path $ExtensionTarget "popup.html"
$manifest = Join-Path $ExtensionTarget "manifest.json"

Replace-RegexOnce $background "const\s+WEB_APP_URL\s*=\s*['\`"]([^'\`"]+)['\`"]\s*;" "const WEB_APP_URL = '$ApiUrl';" "background API URL"
Replace-RegexOnce $popupJs "const\s+WEB_APP_URL\s*=\s*['\`"]([^'\`"]+)['\`"]\s*;" "const WEB_APP_URL = '$DocumentsUrl';" "popup Web App URL"
Replace-RegexOnce $manifest '"version"\s*:\s*"[^"]+"' '"version": "1.8.29"' "manifest version"

Get-ChildItem -LiteralPath $ExtensionTarget -Include *.js,*.html,*.json,*.md,*.txt -Recurse -File | ForEach-Object {
  $text = Read-TextFile $_.FullName
  $updated = $text
  $updated = [regex]::Replace($updated, "SMARTAREA_POST_GAS", "SMARTAREA_POST_IMPORT_API")
  $updated = [regex]::Replace($updated, "postToGas", "postToImportApi")
  $updated = [regex]::Replace($updated, "GAS request failed", "Import API request failed")
  $updated = [regex]::Replace($updated, "lookbackPages:\s*fullSync\s*\?\s*0\s*:\s*\d+", "lookbackPages: fullSync ? 0 : $RecentLookbackPages")
  $updated = [regex]::Replace($updated, "lookbackPages:\s*Number\((message|options)\.lookbackPages\s*\|\|\s*\d+\)", "lookbackPages: Number(`$1.lookbackPages || $RecentLookbackPages)")
  $updated = [regex]::Replace($updated, "1\.8\.19|1\.8\.20|1\.8\.21|1\.8\.22|1\.8\.23|1\.8\.24|1\.8\.25|1\.8\.26|1\.8\.27|1\.8\.28", $Version)
  $updated = [regex]::Replace($updated, "startPage:\s*155", "startPage: $FullReconcileStartPage")
  $updated = [regex]::Replace($updated, "Number\(message\.startPage \|\| 155\)", "Number(message.startPage || $FullReconcileStartPage)")
  if ($updated -ne $text) { Write-TextFileUtf8Bom $_.FullName $updated }
}

$contentText = Read-TextFile $content
$contentText = [regex]::Replace($contentText, "(?m)^const\s+SMARTAREA_WEB_APP_URL\s*=\s*['\`"]([^'\`"]+)['\`"]\s*;\s*`r?`n", "")
Write-TextFileUtf8Bom $content $contentText

$footerBlock = @"
<!-- IMPORT_AREA_PMS_FOOTER_START -->
  <footer id="extensionFooter" class="extensionFooter">
    <div>Version $Version</div>
    <a id="installGuideLink" href="INSTALL-GUIDE.md" target="_blank" rel="noopener">Install guide</a>
  </footer>
<!-- IMPORT_AREA_PMS_FOOTER_END -->
"@
Ensure-RegexBlock $popupHtml "<!-- IMPORT_AREA_PMS_FOOTER_START -->" "<!-- IMPORT_AREA_PMS_FOOTER_END -->" $footerBlock '\s*<script\s+src="popup\.js"></script>' "popup footer"

$guideHandler = @"
// IMPORT_AREA_PMS_GUIDE_LINK_START
const installGuideLink = document.getElementById('installGuideLink');
if (installGuideLink) {
  installGuideLink.addEventListener('click', event => {
    event.preventDefault();
    chrome.tabs.create({ url: chrome.runtime.getURL('INSTALL-GUIDE.md') });
  });
}
// IMPORT_AREA_PMS_GUIDE_LINK_END
"@
Ensure-RegexBlock $popupJs "// IMPORT_AREA_PMS_GUIDE_LINK_START" "// IMPORT_AREA_PMS_GUIDE_LINK_END" $guideHandler "\s*loadLoginSettings\(\);" "popup guide link handler"

if (-not $SkipApiPatch) {
  $apiRoute = Join-Path $ProjectPath "app\api\documents\import-area-pms\route.ts"
  if (Test-Path -LiteralPath $apiRoute) {
    $apiText = Read-TextFile $apiRoute
    $helperBlock = @"
// IMPORT_AREA_PMS_GARBLED_GUARD_START
function importQuestionMarkRatio(value: unknown) {
  const raw = String(value ?? "").replace(/\s+/g, "");
  if (!raw) return 0;
  return (raw.match(/\?/g) || []).length / raw.length;
}

function importHasMeaningfulText(value: unknown) {
  return /[\u0E00-\u0E7Fa-zA-Z0-9]/.test(String(value ?? ""));
}

function importLooksGarbled(value: unknown) {
  const raw = String(value ?? "").trim();
  if (!raw) return false;
  const compact = raw.replace(/\s+/g, "");
  return /^\?+$/.test(compact) || (compact.length >= 6 && importQuestionMarkRatio(compact) >= 0.5 && !importHasMeaningfulText(compact));
}

function importGarbledFields(values: Record<string, unknown>) {
  return Object.entries(values)
    .filter(([, value]) => importLooksGarbled(value))
    .map(([key]) => key);
}
// IMPORT_AREA_PMS_GARBLED_GUARD_END
"@
    if ($apiText -notmatch "IMPORT_AREA_PMS_GARBLED_GUARD_START") {
      $apiText = [regex]::Replace($apiText, "(function\s+number\(value:\s*unknown\)\s*\{[\s\S]*?\n\}\s*)", [System.Text.RegularExpressions.MatchEvaluator]{ param($m) $m.Value + "`r`n" + $helperBlock + "`r`n" }, [System.Text.RegularExpressions.RegexOptions]::Singleline)
    }
    $guardBlock = @"
  // IMPORT_AREA_PMS_UPSERT_GARBLED_CHECK_START
  const garbledFields = importGarbledFields({
    subject: item.subject,
    sender: item.sender,
    documentNo: item.documentNo,
    receiveNo: item.receiveNo,
    summary: item.summary,
  });
  if (garbledFields.length) {
    return json({
      ok: false,
      message: "Garbled Thai text detected",
      fields: garbledFields,
      smartAreaId: item.smartAreaId,
    }, 400);
  }
  // IMPORT_AREA_PMS_UPSERT_GARBLED_CHECK_END
"@
    if ($apiText -notmatch "IMPORT_AREA_PMS_UPSERT_GARBLED_CHECK_START") {
      $apiText = [regex]::Replace($apiText, "(\s*if \(!item\.smartAreaId\) \{[\s\S]*?\n\s*\}\s*\n\s*if \(!item\.subject\) \{[\s\S]*?\n\s*\}\s*)", [System.Text.RegularExpressions.MatchEvaluator]{ param($m) $m.Value + "`r`n" + $guardBlock }, [System.Text.RegularExpressions.RegexOptions]::Singleline)
    }
    Write-TextFileUtf8Bom $apiRoute $apiText
    Write-Host "API guard patch checked: $apiRoute"
  } else {
    Write-Host "API route not found, skipped: $apiRoute"
  }
}

Write-Host "Done."
Write-Host "Open Chrome extensions: chrome://extensions"
Write-Host "Enable Developer mode, select Load unpacked, then choose: $ExtensionTarget"
Write-Host "No git add, commit, push, deploy, clean, or reset was executed."
