Import Area PMS 1.8.30 installer. Install the extension, reload it in Chrome, and import from the Smart Area receive page.
