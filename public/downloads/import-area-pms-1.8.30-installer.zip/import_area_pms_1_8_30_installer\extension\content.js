window.addEventListener('message', event => {
  if (event.source === window && event.data && event.data.type === 'SMARTAREA_OPEN_EXTENSION_SIGNER') {
    chrome.runtime.sendMessage({
      type: 'SMARTAREA_OPEN_SIGNER',
      payload: event.data.payload || {}
    }, response => {
      const error = chrome.runtime.lastError && chrome.runtime.lastError.message;
      window.postMessage({
        type: 'SMARTAREA_OPEN_EXTENSION_SIGNER_RESULT',
        requestId: event.data.requestId || '',
        ok: Boolean(!error && response && response.ok),
        error: error || response && response.error || ''
      }, '*');
    });
    return;
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === 'SMARTAREA_FILL_LOGIN') {
    fillSmartAreaLogin(Boolean(message.forceSubmit)).then(result => sendResponse(result));
    return true;
  }
  if (message && message.type === 'SMARTAREA_IMPORT_PAGE') {
    importSmartAreaPage({
      silent: Boolean(message.silent),
      strictPageCoverage: Boolean(message.strictPageCoverage),
      lookbackPages: Number(message.lookbackPages || 3)
    })
      .then(result => sendResponse({ ok: true, result }))
      .catch(error => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }
  if (message && message.type === 'SMARTAREA_IMPORT_FROM_PAGE') {
    importSmartAreaPage({
      startPage: Number(message.startPage || 1),
      silent: Boolean(message.silent),
      strictPageCoverage: Boolean(message.strictPageCoverage)
    })
      .then(result => sendResponse({ ok: true, result }))
      .catch(error => sendResponse({ ok: false, error: error.message || String(error) }));
    return true;
  }
});

function getSmartAreaLoginSettings() {
  return new Promise(resolve => {
    chrome.storage.local.get(['smartAreaUsername', 'smartAreaPassword', 'smartAreaAutoSubmit'], data => resolve(data));
  });
}

function findSmartAreaLoginFields() {
  const password = document.querySelector('input[type="password"]');
  if (!password) return null;

  const forms = [...document.querySelectorAll('form')];
  const form = password.closest('form') || forms[0] || document;
  const userSelectors = [
    'input[name*="user" i]',
    'input[id*="user" i]',
    'input[name*="login" i]',
    'input[id*="login" i]',
    'input[name*="name" i]',
    'input[type="text"]'
  ];
  const username = userSelectors
    .map(selector => form.querySelector(selector))
    .find(input => input && input !== password);

  if (!username) return null;
  const submit = form.querySelector('button[type="submit"], input[type="submit"], button, input[type="button"]');
  return { form, username, password, submit };
}

function setNativeValue(input, value) {
  input.focus();
  input.value = value;
  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
}

async function fillSmartAreaLogin(forceSubmit = false) {
  const settings = await getSmartAreaLoginSettings();
  if (!settings.smartAreaUsername || !settings.smartAreaPassword) {
    return { ok: false, message: 'ยังไม่ได้บันทึกบัญชี Smart Area' };
  }

  const fields = findSmartAreaLoginFields();
  if (!fields) {
    return { ok: false, message: 'ไม่พบช่องเข้าสู่ระบบในหน้านี้' };
  }

  setNativeValue(fields.username, settings.smartAreaUsername);
  setNativeValue(fields.password, settings.smartAreaPassword);

  if (forceSubmit || settings.smartAreaAutoSubmit) {
    setTimeout(() => {
      if (fields.submit) fields.submit.click();
      else if (fields.form && fields.form.submit) fields.form.submit();
    }, 250);
    return { ok: true, submitted: true, message: 'กรอกบัญชีและกำลังเข้าสู่ระบบ' };
  }

  return { ok: true, submitted: false, message: 'กรอกบัญชีแล้ว กรุณากดเข้าสู่ระบบ' };
}

setTimeout(() => {
  if (findSmartAreaLoginFields()) {
    fillSmartAreaLogin(false).catch(error => console.warn(error));
  }
}, 700);

async function importSmartAreaPage(options = {}) {
  const th = {
    detailTitle: '\u0e23\u0e32\u0e22\u0e25\u0e30\u0e40\u0e2d\u0e35\u0e22\u0e14\u0e2b\u0e19\u0e31\u0e07\u0e2a\u0e37\u0e2d',
    at: '\u0e17\u0e35\u0e48',
    subject: '\u0e40\u0e23\u0e37\u0e48\u0e2d\u0e07',
    receive: '\u0e40\u0e25\u0e02\u0e17\u0e30\u0e40\u0e1a\u0e35\u0e22\u0e19\u0e2b\u0e19\u0e31\u0e07\u0e2a\u0e37\u0e2d\u0e23\u0e31\u0e1a',
    date: '\u0e2b\u0e19\u0e31\u0e07\u0e2a\u0e37\u0e2d\u0e25\u0e07\u0e27\u0e31\u0e19\u0e17\u0e35\u0e48',
    sender: '\u0e2a\u0e48\u0e07\u0e42\u0e14\u0e22',
    sentAt: '\u0e27\u0e31\u0e19\u0e40\u0e27\u0e25\u0e32\u0e17\u0e35\u0e48\u0e2a\u0e48\u0e07',
    summary: '\u0e40\u0e19\u0e37\u0e49\u0e2d\u0e2b\u0e32\u0e42\u0e14\u0e22\u0e2a\u0e23\u0e38\u0e1b',
    attach: '\u0e44\u0e1f\u0e25\u0e4c\u0e41\u0e19\u0e1a',
    sendTo: '\u0e2a\u0e48\u0e07\u0e16\u0e36\u0e07'
  };

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const DETAIL_CONCURRENCY = 4;
  const DETAIL_TIMEOUT_MS = 15000;
  const RECENT_LOOKBACK_PAGES = 3;

  const sendProgress = message => {
    chrome.runtime.sendMessage({ type: 'SMARTAREA_IMPORT_PROGRESS', message }, () => {});
  };
  const clean = value => (value || '').replace(/\s+/g, ' ').trim();
  const esc = value => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const htmlEscape = value => String(value || '').replace(/[<>&]/g, char => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;' }[char]));
  const hasMeaningfulText = value => /[\u0E00-\u0E7Fa-zA-Z0-9]/.test(String(value || ''));
  const questionMarkRatio = value => {
    const text = String(value || '').replace(/\s+/g, '');
    if (!text) return 0;
    return (text.match(/\?/g) || []).length / text.length;
  };
  const looksGarbled = value => {
    const text = String(value || '').trim();
    if (!text) return false;
    return /^\?+$/.test(text.replace(/\s+/g, '')) || (text.length >= 6 && questionMarkRatio(text) >= 0.5 && !hasMeaningfulText(text));
  };
  const fixUrl = value => {
    const url = String(value || '')
      .trim()
      .replace(/%20https?:\/\//i, ' http://')
      .replace(/\s+https?:\/\/.*$/i, '')
      .replace(/(\/n\d+\.?).*$/i, '');
    const match = url.match(/^(.*?\.(?:pdf|docx?|xlsx?|pptx?|jpe?g|png|zip|rar))/i);
    return match ? match[1] : url;
  };

  const DETAIL_PAGE_FILE = 'bookdetail_school_saraban.php';
  const detailUrl = (id, baseHref = location.href) => new URL(`modules/book/main/${DETAIL_PAGE_FILE}?b_id=${id}`, baseHref).href;
  const receivePageUrl = (page, baseHref = location.href) => {
    const url = new URL('index.php', baseHref);
    url.searchParams.set('option', 'book');
    url.searchParams.set('task', 'main/receive');
    if (!url.searchParams.has('saraban_index')) url.searchParams.set('saraban_index', '');
    if (!url.searchParams.has('search_index')) url.searchParams.set('search_index', '');
    if (!url.searchParams.has('field')) url.searchParams.set('field', '');
    if (!url.searchParams.has('search')) url.searchParams.set('search', '');
    url.searchParams.set('page', String(page));
    return url.href;
  };

  const detectCharset = (response, buffer) => {
    const header = response.headers.get('content-type') || '';
    const headerMatch = header.match(/charset=([^;]+)/i);
    if (headerMatch) return headerMatch[1].trim().toLowerCase();

    try {
      const sample = new TextDecoder('ascii').decode(buffer.slice(0, 4096));
      const metaMatch = sample.match(/charset=["']?([^"'\s/>]+)/i);
      if (metaMatch) return metaMatch[1].trim().toLowerCase();
    } catch (error) {
      // Ignore charset sniffing errors and use UTF-8 fallback.
    }

    return 'utf-8';
  };

  const decodeHtmlBuffer = (response, buffer) => {
    const charset = detectCharset(response, buffer);
    const candidates = [];
    if (/^(windows-874|tis-620|iso-8859-11|x-user-defined)$/i.test(charset)) {
      candidates.push('windows-874');
    } else {
      candidates.push(charset || 'utf-8');
    }
    candidates.push('utf-8', 'windows-874');

    let best = '';
    let bestScore = -Infinity;
    [...new Set(candidates)].forEach(label => {
      try {
        const decoded = new TextDecoder(label).decode(buffer);
        const thaiCount = (decoded.match(/[฀-๿]/g) || []).length;
        const replacementCount = (decoded.match(/�/g) || []).length;
        const questionCount = (decoded.match(/\?/g) || []).length;
        const score = thaiCount * 4 - replacementCount * 20 - questionCount;
        if (score > bestScore) {
          bestScore = score;
          best = decoded;
        }
      } catch (error) {
        // Ignore unsupported charset labels.
      }
    });

    return best;
  };

  const fetchTextWithTimeout = async (url, timeoutMs = DETAIL_TIMEOUT_MS) => {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(url, {
        credentials: 'include',
        signal: controller.signal
      });
      const buffer = await response.arrayBuffer();
      return decodeHtmlBuffer(response, buffer);
    } finally {
      clearTimeout(timeout);
    }
  };

  const postToImportApi = data => {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: 'SMARTAREA_POST_IMPORT_API', payload: data }, response => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        if (!response || !response.ok) {
          reject(new Error((response && response.error) || 'Import API request failed'));
          return;
        }
        resolve(response.result);
      });
    });
  };

  const getImportScanPlan = latestPage => postToImportApi({
    action: 'getImportScanPlan',
    latestPage: latestPage || ''
  });

  const finalizeImportScan = summary => postToImportApi({
    action: 'finalizeImportScan',
    ...summary
  });

  const checkExistingSmartAreaItems = items => postToImportApi({
    action: 'checkExistingSmartAreaItems',
    items: items.map(item => ({
      id: item.id || '',
      smartAreaId: item.id || '',
      url: item.url || ''
    }))
  });

  const openReport = () => {
    const report = window.open('about:blank', '_blank');
    if (!report) {
      alert('Chrome blocked the report page. Please allow popups and try again.');
      return null;
    }

    report.document.open();
    report.document.write(`
      <meta charset="utf-8">
      <title>Smart Area import report</title>
      <style>
        body{font-family:sans-serif;padding:20px;line-height:1.45}
        table{border-collapse:collapse;width:100%}
        td,th{border:1px solid #ccc;padding:6px;vertical-align:top}
        .ok{color:#087f23}.fail{color:#b00020}
      </style>
      <h2>Smart Area import report</h2>
      <p id="sum">Starting...</p>
      <table>
        <thead><tr><th>#</th><th>Status</th><th>Smart Area ID</th><th>Receive No.</th><th>Files</th><th>Subject / Message</th><th>Detail URL</th></tr></thead>
        <tbody id="body"></tbody>
      </table>
    `);
    report.document.close();
    return report;
  };

  const addRow = (report, index, row) => {
    const cls = ['Sent', 'saved', 'updated', 'duplicate'].includes(row.status) ? 'ok' : 'fail';
    report.document.getElementById('body').insertAdjacentHTML('beforeend', `
      <tr>
        <td>${index}</td>
        <td class="${cls}">${htmlEscape(row.status)}</td>
        <td>${htmlEscape(row.id)}</td>
        <td>${htmlEscape(row.receiveNo)}</td>
        <td>${htmlEscape(row.fileCount || 0)}</td>
        <td>${htmlEscape(row.subject || row.message)}</td>
        <td>${htmlEscape(row.detailUrl || '')}</td>
      </tr>
    `);
  };

  const setSum = (report, text) => {
    report.document.getElementById('sum').textContent = text;
  };

  const getAttachmentLinks = (doc, baseUrl) => {
    const allowed = anchor => {
      const text = clean(anchor.innerText);
      const href = anchor.getAttribute('href') || '';
      const url = fixUrl(new URL(href, baseUrl).href);
      if (!text || !href || /^javascript:/i.test(href)) return null;
      if (/\.(pdf|docx?|xlsx?|pptx?|jpe?g|png|zip|rar)/i.test(url) || /upload_files/i.test(url)) {
        return { text, url };
      }
      return null;
    };

    const linksFrom = root => [...root.querySelectorAll('a')]
      .map(allowed)
      .filter(Boolean);

    let links = [];

    // Smart Area detail pages usually keep attachments in the table row whose
    // left cell says "ไฟล์แนบ". Prefer that exact row before using broad scans.
    const attachmentLabel = [...doc.querySelectorAll('td,th,div,span')]
      .find(element => clean(element.innerText) === th.attach);
    if (attachmentLabel) {
      const row = attachmentLabel.closest('tr');
      if (row) links = linksFrom(row);
    }

    const bodyText = doc.body.innerText;
    const start = bodyText.indexOf(th.attach);
    const end = bodyText.indexOf(th.sendTo, start > -1 ? start : 0);
    if (start > -1) {
      const zoneLinks = [...doc.querySelectorAll('tr,td,div,span')]
        .filter(element => {
          const text = element.innerText || '';
          const pos = bodyText.indexOf(text);
          return pos >= start && (end < 0 || pos <= end);
        })
        .flatMap(linksFrom);
      links = links.concat(zoneLinks);
    }

    if (!links.length) {
      links = linksFrom(doc);
    }

    const seen = new Set();
    return links.filter(link => {
      const key = `${link.text}|${link.url}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  };

  const parseDetail = (html, baseUrl) => {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const text = doc.body.innerText;
    const hasDetailLabels = text.includes(th.detailTitle) || text.includes(th.subject) || text.includes(th.receive) || text.includes(th.sender) || text.includes(th.attach);
    if (!hasDetailLabels) return null;

    const pick = label => {
      const match = text.match(new RegExp(`${esc(label)}\\s*:?\\s*([^\\n]+)`));
      return match ? clean(match[1]) : '';
    };
    const between = (start, end) => {
      const match = text.match(new RegExp(`${esc(start)}\\s*([\\s\\S]*?)\\s*${esc(end)}`));
      return match ? clean(match[1]) : '';
    };

    const titleMatch = text.match(new RegExp(`${esc(th.detailTitle)}\\s*${esc(th.at)}\\s*([^\\n]+)`));
    const subjectMatch = text.match(new RegExp(`${esc(th.subject)}\\s*:?\\s*([\\s\\S]*?)\\s*\\[\\s*([^\\]]+)\\s*\\]`));
    const fileLinks = getAttachmentLinks(doc, baseUrl);
    const rawDocumentNo = titleMatch ? clean(titleMatch[1]) : '';
    const documentNo = rawDocumentNo
      .replace(new RegExp(`\\s*${esc(th.subject)}\\s*:.*$`), '')
      .trim();
    const validDocumentNo = documentNo &&
      documentNo.length <= 100 &&
      /\d/.test(documentNo) &&
      !documentNo.includes(th.subject)
        ? documentNo
        : '';

    return {
      action: 'upsertDocument',
      sourceUrl: baseUrl,
      smartAreaId: (baseUrl.match(/[?&]b_id=(\d+)/i) || [])[1] || '',
      documentNo: validDocumentNo,
      subject: subjectMatch ? clean(subjectMatch[1]) : pick(th.subject),
      priority: subjectMatch ? clean(subjectMatch[2]) : '',
      receiveNo: pick(th.receive),
      documentDate: pick(th.date),
      sender: pick(th.sender),
      sentAt: pick(th.sentAt),
      summary: between(th.summary, th.attach),
      attachmentText: fileLinks.map((link, index) => `${index + 1}. ${link.text}`).join('\n'),
      attachmentUrl: fileLinks.map((link, index) => `${index + 1}. ${link.url}`).join('\n'),
      fileCount: fileLinks.length
    };
  };

  const collectItemsFromDocument = (doc, baseHref) => {
    const items = [];
    let rowOrder = 0;

    const addItem = (id, url, element) => {
      const normalizedId = clean(id);
      if (!normalizedId || !/^\d+$/.test(normalizedId) || !url) return;

      rowOrder += 1;
      const row = element && element.closest ? element.closest('tr') : null;
      const rowText = clean(row ? row.innerText : element && element.innerText || '');
      const subjectPreview = rowText
        .replace(/\s+/g, ' ')
        .slice(0, 500);

      items.push({
        id: normalizedId,
        url,
        rowOrder,
        subjectPreview
      });
    };

    const extractBookId = value => {
      const raw = String(value || '');
      const match =
        raw.match(/[?&]b_id=(\d+)/i) ||
        raw.match(/check\s*\(\s*['"][^'"]+['"]\s*,\s*['"]?(\d+)['"]?/i) ||
        raw.match(/bookdetail_school_saraban\.php[^'"<>]*?b_id=(\d+)/i) ||
        raw.match(/\bb_id\s*[:=]\s*['"]?(\d+)/i);
      return match ? clean(match[1]) : '';
    };

    const resolveDetailUrl = (root, fallbackId) => {
      const nodes = [root, ...root.querySelectorAll('[onclick], a[href], [data-href], [data-url], [data-id], input[value], button, img')];
      for (const node of nodes) {
        const onclick = node.getAttribute('onclick') || '';
        const href = node.getAttribute('href') || node.getAttribute('data-href') || node.getAttribute('data-url') || '';
        const value = node.getAttribute('value') || node.getAttribute('data-id') || '';
        const combined = `${onclick} ${href} ${value} ${node.outerHTML || ''}`;
        const id = extractBookId(combined) || clean(fallbackId);
        if (!id) continue;

        if (href && !/^javascript:/i.test(href)) {
          try {
            const hrefUrl = new URL(href, baseHref).href;
            if (/[?&]b_id=/i.test(hrefUrl) || /bookdetail_school_saraban\.php/i.test(hrefUrl)) {
              return hrefUrl;
            }
          } catch (error) {
            // Ignore malformed detail URLs and use the forced detail URL.
          }
        }

        return detailUrl(id, baseHref);
      }
      return clean(fallbackId) ? detailUrl(fallbackId, baseHref) : '';
    };

    // The central Smart Area receive list keeps the real open-detail control in
    // the column named "รายละเอียด" as a document icon. Prefer that column and
    // use the first column as the book id, then fall back to broad scans.
    const tableRows = [...doc.querySelectorAll('table tr')];
    let detailColumnIndex = -1;
    for (const row of tableRows) {
      const cells = [...row.children].filter(cell => /^(TD|TH)$/i.test(cell.tagName));
      const labels = cells.map(cell => clean(cell.innerText || cell.textContent || ''));
      const found = labels.findIndex(label => label === 'รายละเอียด' || label.includes('รายละเอียด'));
      if (found >= 0) {
        detailColumnIndex = found;
        break;
      }
    }

    tableRows.forEach(row => {
      const cells = [...row.children].filter(cell => /^(TD|TH)$/i.test(cell.tagName));
      if (cells.length < 4 || cells[0].tagName.toUpperCase() === 'TH') return;

      const firstCellId = clean(cells[0].innerText || cells[0].textContent || '').match(/^\d{3,}$/);
      const detailCell = detailColumnIndex >= 0 ? cells[detailColumnIndex] : null;
      const detailRoot = detailCell || cells.find(cell => /รายละเอียด|bookdetail|b_id|check\s*\(/i.test(cell.innerHTML || '')) || row;
      const id = extractBookId(detailRoot.innerHTML || '') || (firstCellId ? firstCellId[0] : '');
      const url = resolveDetailUrl(detailRoot, id);
      if (id && url) addItem(id, url, detailRoot);
    });

    const candidates = [
      ...doc.querySelectorAll(
        '[onclick], a[href], [data-href], [data-url], [data-id], input[value], button'
      )
    ];

    candidates.forEach(element => {
      const onclick = element.getAttribute('onclick') || '';
      const href =
        element.getAttribute('href') ||
        element.getAttribute('data-href') ||
        element.getAttribute('data-url') ||
        '';
      const value = element.getAttribute('value') || '';
      const combined = `${onclick} ${href} ${value}`;

      // Original Smart Area format:
      // check('bookdetail_school_saraban.php', 12345, ...) or older Smart Area variants
      const checkMatch = onclick.match(
        /check\s*\(\s*['"]([^'"]+)['"]\s*,\s*['"]?(\d+)['"]?(?:\s*,[^)]*)?\)/i
      );
      if (checkMatch) {
        addItem(
          checkMatch[2],
          detailUrl(checkMatch[2], baseHref),
          element
        );
        return;
      }

      // Alternate functions or direct attributes containing b_id.
      const idMatch =
        combined.match(/[?&]b_id=(\d+)/i) ||
        combined.match(/\bb_id\s*[:=]\s*['"]?(\d+)/i) ||
        combined.match(/\bbook[_-]?id\s*[:=]\s*['"]?(\d+)/i);

      if (!idMatch) return;

      const id = idMatch[1];
      let targetUrl = '';

      try {
        if (href && !/^javascript:/i.test(href)) {
          targetUrl = new URL(href, baseHref).href;
        }
      } catch (error) {
        targetUrl = '';
      }

      if (!targetUrl || !/[?&]b_id=/i.test(targetUrl)) {
        targetUrl = detailUrl(id, baseHref);
      }

      addItem(id, targetUrl, element);
    });

    const unique = new Map();
    items.forEach(item => {
      if (!unique.has(item.id)) unique.set(item.id, item);
    });

    return [...unique.values()].sort(
      (left, right) => Number(left.rowOrder || 0) - Number(right.rowOrder || 0)
    );
  };

  const parsePageInfo = doc => {
    const text = clean(doc.body && doc.body.innerText || '').replace(/,/g, '');
    const patterns = [
      /หน้า(?:ที่)?\s*(\d+)\s*(?:จาก|\/)\s*(\d+)/i,
      /page\s*(\d+)\s*(?:of|\/)\s*(\d+)/i,
      /(?:จาก|ทั้งหมด)\s*(\d+)\s*หน้า/i
    ];
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (!match) continue;
      const total = Number(match[2] || match[1] || 0);
      const current = Number(match[2] ? match[1] : 0);
      if (total > 0) return { current, total };
    }
    return { current: 0, total: 0 };
  };

  const pageFromText = value => {
    const text = clean(value).replace(/,/g, '');
    const exact = text.match(/^\d+$/);
    if (exact) return Number(exact[0]);
    const pageText = text.match(/(?:หน้า|page)\s*(\d+)/i);
    return pageText ? Number(pageText[1]) : 0;
  };

  const pageFromUrl = value => {
    try {
      const url = new URL(value, location.href);
      const keys = ['page', 'p', 'start', 'offset', 'limitstart', 'saraban_index'];
      for (const key of keys) {
        const page = Number(url.searchParams.get(key) || 0);
        if (Number.isInteger(page) && page > 0) return page;
      }
    } catch (error) {
      // Ignore malformed pagination URLs.
    }
    return 0;
  };

  const urlFromElement = element => {
    const rawUrl = element.getAttribute('href') || element.getAttribute('value') || '';
    if (!rawUrl || /^javascript:\s*void/i.test(rawUrl) || rawUrl === '#') return '';
    if (/^javascript:/i.test(rawUrl)) {
      const match = rawUrl.match(/(?:page|p|start|offset|limitstart|saraban_index)\D*(\d+)/i) ||
        rawUrl.match(/\((\d+)\)/);
      if (!match) return '';
      return inferPageUrl(getPageLinks(false), Number(match[1]));
    }
    return new URL(rawUrl, location.href).href;
  };

  const getPageLinks = (includeJavascript = true, root = document) => [...root.querySelectorAll('a[href], option[value]')]
    .map(element => {
      const page = pageFromText(element.innerText || element.textContent || '');
      const rawUrl = element.getAttribute('href') || element.getAttribute('value') || '';
      if (!page || !rawUrl || (!includeJavascript && /^javascript:/i.test(rawUrl))) return null;
      const url = urlFromElement(element);
      return url ? { page, url } : null;
    })
    .filter(Boolean);

  const getDirectionalPageLinks = (root = document) => [...root.querySelectorAll('a[href], option[value]')]
    .map(element => {
      const text = clean(element.innerText || element.textContent || element.getAttribute('title') || '');
      const rawUrl = element.getAttribute('href') || element.getAttribute('value') || '';
      if (!rawUrl || /^javascript:\s*void/i.test(rawUrl) || rawUrl === '#') return null;
      const url = urlFromElement(element);
      if (!url) return null;
      return { text, url };
    })
    .filter(Boolean);

  const inferPageUrl = (pageLinks, targetPage) => {
    const exact = pageLinks.find(link => link.page === targetPage);
    if (exact) return exact.url;

    for (const link of pageLinks) {
      try {
        const url = new URL(link.url, location.href);
        for (const [key, value] of url.searchParams.entries()) {
          if (Number(value) === Number(link.page)) {
            url.searchParams.set(key, String(targetPage));
            return url.href;
          }
        }
      } catch (error) {
        // Ignore malformed links and try the next pagination hint.
      }
    }

    const template = pageLinks.find(link => String(link.url).includes(String(link.page)));
    return template
      ? String(template.url).replace(new RegExp(`(^|[^\\d])${template.page}([^\\d]|$)`), `$1${targetPage}$2`)
      : '';
  };

  const collectPageUrls = (startPage, endPage) => {
    if (!startPage) return [{ page: null, url: location.href, current: true }];
    const pages = [];
    const pageLinks = getPageLinks();
    pageLinks.forEach(link => {
      if (link.page < startPage || link.page > endPage) return;
      pages.push({ page: link.page, url: link.url, current: false });
    });

    const pageInfo = parsePageInfo(document);
    if (pageInfo.current >= startPage && pageInfo.current <= endPage) {
      pages.push({ page: pageInfo.current, url: location.href, current: true });
    }

    const currentUrlPage = pageFromUrl(location.href);
    if (!currentUrlPage && endPage >= startPage && !pages.some(page => page.current)) {
      pages.push({ page: endPage, url: location.href, current: true });
    }

    const knownPages = new Set(pages.map(page => page.page));
    for (let page = startPage; page <= endPage; page++) {
      if (knownPages.has(page)) continue;
      const inferredUrl = inferPageUrl(pageLinks, page) || receivePageUrl(page);
      if (inferredUrl) pages.push({ page, url: inferredUrl, current: inferredUrl === location.href });
    }

    return [...new Map(pages.map(page => [page.page, page])).values()]
      .sort((a, b) => a.page - b.page);
  };

  const findLatestPageInfo = async () => {
    const firstPageInfo = parsePageInfo(document);
    const pageNumbersFromDoc = root => getPageLinks(true, root)
      .map(link => link.page)
      .filter(page => Number.isInteger(page) && page > 0);
    const visiblePageNumbers = pageNumbersFromDoc(document);
    let latestPage = firstPageInfo.total || Math.max(0, ...visiblePageNumbers);
    const visitedUrls = new Set([location.href]);
    const lastPattern = /(\u0E2A\u0E38\u0E14\u0E17\u0E49\u0E32\u0E22|\u0E17\u0E49\u0E32\u0E22|last|>>|\u00BB)/i;
    const nextPattern = /(\u0E16\u0E31\u0E14\u0E44\u0E1B|\u0E15\u0E48\u0E2D\u0E44\u0E1B|next|>|\u203A)/i;

    const absorbPage = (root, sourceUrl = '') => {
      const info = parsePageInfo(root);
      const pages = pageNumbersFromDoc(root);
      latestPage = Math.max(
        latestPage,
        pageFromUrl(sourceUrl),
        info.total || 0,
        info.current || 0,
        ...pages
      );
    };

    const readPage = async url => {
      const html = await fetchTextWithTimeout(url);
      return new DOMParser().parseFromString(html, 'text/html');
    };

    let currentDoc = document;
    absorbPage(currentDoc, location.href);

    const firstLastLink = getDirectionalPageLinks(currentDoc)
      .find(link => lastPattern.test(link.text));
    if (firstLastLink && firstLastLink.url && !visitedUrls.has(firstLastLink.url)) {
      try {
        visitedUrls.add(firstLastLink.url);
        currentDoc = await readPage(firstLastLink.url);
        absorbPage(currentDoc, firstLastLink.url);
      } catch (error) {
        console.warn('Could not read last page', error);
      }
    }

    for (let hop = 0; hop < 30; hop++) {
      const links = getDirectionalPageLinks(currentDoc);
      const nextLink = links.find(link =>
        nextPattern.test(link.text) && !lastPattern.test(link.text)
      ) || links
        .filter(link => pageFromUrl(link.url) > latestPage)
        .sort((left, right) => pageFromUrl(left.url) - pageFromUrl(right.url))[0];

      if (!nextLink || !nextLink.url || visitedUrls.has(nextLink.url)) break;

      try {
        visitedUrls.add(nextLink.url);
        currentDoc = await readPage(nextLink.url);
        const before = latestPage;
        absorbPage(currentDoc, nextLink.url);
        const stillHasNext = getDirectionalPageLinks(currentDoc).some(link =>
          nextPattern.test(link.text) && !lastPattern.test(link.text) && !visitedUrls.has(link.url)
        );
        if (latestPage <= before && !stillHasNext) break;
      } catch (error) {
        console.warn('Could not read next page', error);
        break;
      }
    }

    return {
      current: firstPageInfo.current,
      total: latestPage,
      visiblePageNumbers
    };
  };

  const pageInfo = await findLatestPageInfo();
  const visiblePageNumbers = getPageLinks().map(link => link.page);
  const centralLatestPage = pageInfo.total || Math.max(0, ...visiblePageNumbers);
  const scanPlan = options.startPage
    ? {
      scanStartPage: Number(options.startPage || 1),
      scanEndPage: centralLatestPage || Number(options.startPage || 1)
    }
    : {
      scanStartPage: Math.max(
        1,
        Number(centralLatestPage || 1) -
          Math.max(1, Number(options.lookbackPages || RECENT_LOOKBACK_PAGES)) +
          1
      ),
      scanEndPage: Number(centralLatestPage || 1),
      lookbackPages: Math.max(1, Number(options.lookbackPages || RECENT_LOOKBACK_PAGES))
    };
  const scanStartPage = Number(scanPlan.scanStartPage || options.startPage || 0);
  const scanEndPage = Number(scanPlan.scanEndPage || centralLatestPage || scanStartPage || 0);
  const pageUrls = collectPageUrls(scanStartPage, scanEndPage);
  const expectedPages = [];
  for (let page = scanStartPage; page <= scanEndPage; page++) expectedPages.push(page);

  const preparedPages = new Set(
    pageUrls.map(page => Number(page.page || 0)).filter(page => page > 0)
  );
  const missingPreparedPages = expectedPages.filter(page => !preparedPages.has(page));

  if (options.strictPageCoverage && missingPreparedPages.length > 0) {
    throw new Error(
      `สร้าง URL หน้าไม่ครบ ขาดหน้า ${missingPreparedPages.slice(0, 20).join(', ')}`
      + (missingPreparedPages.length > 20 ? ` และอีก ${missingPreparedPages.length - 20} หน้า` : '')
      + ' ระบบยกเลิกเพื่อป้องกันการเลื่อนหน้าล่าสุดผิด'
    );
  }

  const scannedPages = [];
  const failedPages = [];
  const allItems = [];
  let pageReadFail = 0;
  sendProgress(`กำลังตรวจ ${pageUrls.length} หน้าล่าสุด: ${scanStartPage}-${scanEndPage}`);
  for (let pageIndex = 0; pageIndex < pageUrls.length; pageIndex++) {
    const page = pageUrls[pageIndex];
    try {
      sendProgress(`กำลังอ่านรายการหน้า ${page.page || '-'} (${pageIndex + 1}/${pageUrls.length})`);
      const html = page.current ? document.documentElement.outerHTML : await fetchTextWithTimeout(page.url);
      const doc = new DOMParser().parseFromString(html, 'text/html');
      const documentPageInfo = parsePageInfo(doc);
      const effectivePage = page.page || documentPageInfo.current || pageFromUrl(page.url) || '';
      collectItemsFromDocument(doc, page.url).forEach(item =>
        allItems.push({
          ...item,
          page: Number(effectivePage || 0),
          sourcePageUrl: page.url
        })
      );
      if (effectivePage) scannedPages.push(Number(effectivePage));
      await sleep(120);
    } catch (error) {
      pageReadFail++;
      failedPages.push(Number(page.page || 0));
      console.warn(`Could not read page ${page.page || ''}`, error);
    }
  }

  const uniqueScannedPages = [...new Set(scannedPages)].sort((a, b) => a - b);
  const missingReadPages = expectedPages.filter(page => !uniqueScannedPages.includes(page));

  if (
    options.strictPageCoverage &&
    (pageReadFail > 0 || missingReadPages.length > 0)
  ) {
    throw new Error(
      `อ่านหน้าไม่ครบ: สำเร็จ ${uniqueScannedPages.length}/${expectedPages.length} หน้า`
      + (missingReadPages.length
          ? ` ขาดหน้า ${missingReadPages.slice(0, 20).join(', ')}`
            + (missingReadPages.length > 20 ? ` และอีก ${missingReadPages.length - 20} หน้า` : '')
          : '')
      + ' ระบบยังไม่อัปเดตหน้าล่าสุด'
    );
  }

  const itemMap = new Map();
  allItems
    .sort((left, right) =>
      Number(left.page || 0) - Number(right.page || 0) ||
      Number(left.rowOrder || 0) - Number(right.rowOrder || 0)
    )
    .forEach(item => {
      if (!itemMap.has(item.id)) itemMap.set(item.id, item);
    });

  const items = [...itemMap.values()].sort((left, right) =>
    Number(left.page || 0) - Number(right.page || 0) ||
    Number(left.rowOrder || 0) - Number(right.rowOrder || 0)
  );
  if (!items.length) {
    let finalResult = null;
    try {
      finalResult = await finalizeImportScan({
        scanStartPage,
        scanEndPage,
        pagesScanned: uniqueScannedPages,
        totalFound: 0,
        addedCount: 0,
        duplicateCount: 0,
        errorCount: pageReadFail
      });
    } catch (error) {
      finalResult = { ok: false, message: error.message };
    }
    if (!options.silent) alert('No Smart Area detail commands found.');
    return {
      scanStartPage,
      scanEndPage,
      totalFound: 0,
      addedCount: 0,
      duplicateCount: 0,
      errorCount: pageReadFail,
      finalized: finalResult
    };
  }
  sendProgress(`พบ ${items.length} รายการ กำลังเช็ครายการที่มีในระบบแล้ว`);
  let existingMap = {};
  try {
    const existingResult = await checkExistingSmartAreaItems(items);
    existingMap = existingResult && existingResult.existing ? existingResult.existing : {};
  } catch (error) {
    console.warn('Could not check existing Smart Area items', error);
    sendProgress('เช็ครายการซ้ำไม่สำเร็จ กำลังนำเข้าแบบตรวจละเอียด');
  }
  const existingCount = Object.keys(existingMap).length;
  // Synchronize every item in the selected source pages. Existing IDs must still
  // be opened because the central record or its original attachments may change.
  const itemsToImport = items;
  if (!options.silent && !confirm(`Scan pages ${scanStartPage}-${scanEndPage}. Found ${items.length} detail items from ${pageUrls.length} page(s). Import now?`)) return;

  const report = options.silent ? null : openReport();
  if (!options.silent && !report) return;

  let ok = 0;
  let fail = 0;
  let added = 0;
  let updated = 0;
  let unchanged = 0;
  const imported = [];
  if (report) setSum(report, `Scanning pages ${scanStartPage}-${scanEndPage}. Reading 0/${itemsToImport.length}`);
  sendProgress(`กำลังตรวจรายละเอียด ${itemsToImport.length} รายการ โดยมีข้อมูลเดิม ${existingCount} รายการ`);

  const processItem = async (item, index) => {
    try {
      const html = await fetchTextWithTimeout(item.url);
      const data = parseDetail(html, item.url);
      if (data && (data.smartAreaId || item.id)) {
        data.smartAreaId = data.smartAreaId || item.id || '';
        data.subject = data.subject || item.subjectPreview || `Smart Area ID ${item.id}`;
        data.smartAreaPage = item.page || '';
        data.rowOrder = item.rowOrder || 0;
        data.sourcePageUrl = item.sourcePageUrl || '';
        data.centralLatestPage = centralLatestPage || '';

        if (looksGarbled(data.subject) && item.subjectPreview && !looksGarbled(item.subjectPreview)) {
          data.subject = item.subjectPreview;
        }
        ['sender', 'documentNo', 'receiveNo', 'summary'].forEach(field => {
          if (looksGarbled(data[field])) data[field] = '';
        });

        const garbledFields = ['subject']
          .filter(field => looksGarbled(data[field]));
        if (garbledFields.length) {
          fail++;
          const message = `Garbled text detected in ${garbledFields.join(', ')}`;
          if (report) addRow(report, index + 1, { ...data, id: item.id, status: 'Failed', message });
          return;
        }

        const importResult = await postToImportApi(data);
        ok++;
        if (importResult && importResult.ok) {
          if (importResult.message === 'saved') {
            added++;
            imported.push(data);
          } else if (importResult.message === 'updated') {
            updated++;
          } else if (importResult.message === 'unchanged') {
            unchanged++;
          }
        }
        if (report) addRow(report, index + 1, {
          ...data,
          id: item.id,
          status: importResult && importResult.ok ? (importResult.message || 'Sent') : 'Failed',
          fileCount: importResult && typeof importResult.attachments !== 'undefined' ? importResult.attachments : data.fileCount,
          message: importResult && importResult.message,
          detailUrl: item.url
        });
      } else {
        fail++;
        const previewDoc = new DOMParser().parseFromString(html || '', 'text/html');
        const preview = clean(previewDoc.body && previewDoc.body.innerText || '').slice(0, 240);
        if (report) addRow(report, index + 1, { id: item.id, status: 'Failed', message: `Could not read detail page; page=${item.page || '-'} row=${item.rowOrder || '-'} url=${item.url || '-'} preview=${preview || '-'}`, detailUrl: item.url });
      }
    } catch (error) {
      fail++;
      const message = error && error.name === 'AbortError'
        ? 'Detail page timed out'
        : error.message;
      if (report) addRow(report, index + 1, { id: item.id, status: 'Failed', message: `${message}; url=${item.url || '-'}`, detailUrl: item.url });
    }
  };

  for (let start = 0; start < itemsToImport.length; start += DETAIL_CONCURRENCY) {
    const chunk = itemsToImport.slice(start, start + DETAIL_CONCURRENCY);
    const doneCount = Math.min(start + chunk.length, itemsToImport.length);
    if (report) setSum(report, `Reading ${doneCount}/${itemsToImport.length}`);
    sendProgress(`กำลังซิงก์ ${doneCount}/${itemsToImport.length} รายการ · ใหม่ ${added} · อัปเดต ${updated} · ไม่เปลี่ยน ${unchanged}`);
    await Promise.all(chunk.map((item, offset) => processItem(item, start + offset)));
    await sleep(150);
  }

  let finalMessage = `Done: scanned pages ${scanStartPage}-${scanEndPage}, found ${items.length}, added ${added}, updated ${updated}, unchanged ${unchanged}, failed ${fail + pageReadFail}.`;
  try {
    const finalResult = await finalizeImportScan({
      scanStartPage,
      scanEndPage,
      pagesScanned: uniqueScannedPages,
      totalFound: items.length,
      addedCount: added,
      updatedCount: updated,
      unchangedCount: unchanged,
      duplicateCount: unchanged,
      errorCount: fail + pageReadFail
    });
    if (finalResult && finalResult.ok) {
      finalMessage += ` Latest page updated to ${finalResult.updatedLatestPage || scanEndPage}.`;
    } else if (finalResult && finalResult.message) {
      finalMessage += ` Latest page not updated: ${finalResult.message}`;
    }
  } catch (error) {
    finalMessage += ` Latest page not updated: ${error.message}`;
  }
  if (report) setSum(report, finalMessage);
  sendProgress(`ตรวจเสร็จแล้ว · เพิ่มใหม่ ${added} · อัปเดต ${updated} · ไม่เปลี่ยนแปลง ${unchanged} · ผิดพลาด ${fail + pageReadFail}`);
  return {
    scanStartPage,
    scanEndPage,
    totalFound: items.length,
    addedCount: added,
    updatedCount: updated,
    unchangedCount: unchanged,
    duplicateCount: unchanged,
    errorCount: fail + pageReadFail
  };
}
