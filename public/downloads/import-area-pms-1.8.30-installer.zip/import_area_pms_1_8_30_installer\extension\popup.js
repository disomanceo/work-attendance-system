const WEB_APP_URL = 'https://work-attendance-system-beige.vercel.app/documents';

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function setStatus(text) {
  document.getElementById('status').textContent = text;
}

function setCheckButtonRunning(running) {
  const button = document.getElementById('checkNow');
  if (!button) return;
  button.disabled = Boolean(running);
  button.textContent = running ? 'กำลังอัปเดต...' : 'อัปเดตล่าสุด';
}

function formatThaiTime(value) {
  if (!value) return '-';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '-';
  return date.toLocaleString('th-TH');
}

function statusLabel(status) {
  if (status === 'running') return 'กำลังดึงข้อมูล';
  if (status === 'done') return 'ดึงข้อมูลเสร็จแล้ว';
  if (status === 'error') return 'ดึงข้อมูลไม่สำเร็จ';
  return 'พร้อมทำงาน';
}

function renderStatus(data) {
  const lastRun = data.smartAreaAutoLastRun ? formatThaiTime(data.smartAreaAutoLastRun) : 'ยังไม่เคยตรวจ';
  const nextRun = data.smartAreaAutoNextRun ? formatThaiTime(data.smartAreaAutoNextRun) : '-';
  const importStatus = data.smartAreaImportStatus || {};
  setCheckButtonRunning(importStatus.status === 'running');
  if (!data.smartAreaUsername) {
    setStatus('กรุณาบันทึกบัญชี Smart Area ก่อน');
    return;
  }

  const autoEnabled = Boolean(
    data.smartAreaAutoImport &&
    data.smartAreaAutoImport.enabled === true
  );

  setStatus([
    `${statusLabel(importStatus.status)}: ${importStatus.message || '-'}`,
    `ตรวจอัตโนมัติ: ${autoEnabled ? 'เปิด เมื่อเข้า Chrome + ทุก 1 ชั่วโมง' : 'ปิด'}`,
    `ตรวจล่าสุด: ${lastRun}`,
    `ตรวจถัดไป: ${autoEnabled ? nextRun : '-'}`,
    `ผลล่าสุด: ${data.smartAreaAutoLastResult || '-'}`
  ].join('\n'));
}

async function sendToSmartArea(message, successText) {
  const tab = await getActiveTab();
  if (!tab || !tab.url || !tab.url.startsWith('http://101.51.157.107/smartarea/')) {
    setStatus('กรุณาเปิดหน้ารายการหนังสือรับใน Smart Area ก่อน');
    return;
  }

  setStatus('กำลังสั่งงาน...');
  sendMessageWithContentScript(tab.id, message, response => {
    setStatus(response && response.ok ? successText : 'สั่งงานไม่สำเร็จ');
  });
}

function sendMessageWithContentScript(tabId, message, onSuccess) {
  chrome.tabs.sendMessage(tabId, message, response => {
    if (!chrome.runtime.lastError) {
      onSuccess(response);
      return;
    }
    chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] }, () => {
      if (chrome.runtime.lastError) {
        setStatus('ยังเชื่อมกับหน้า Smart Area ไม่ได้ กรุณารีเฟรชหน้า Smart Area แล้วลองใหม่');
        return;
      }
      chrome.tabs.sendMessage(tabId, message, retryResponse => {
        if (chrome.runtime.lastError) {
          setStatus('ยังเชื่อมกับหน้า Smart Area ไม่ได้ กรุณารีเฟรชหน้า Smart Area แล้วลองใหม่');
          return;
        }
        onSuccess(retryResponse);
      });
    });
  });
}

function loadLoginSettings() {
  chrome.storage.local.get([
    'smartAreaUsername',
    'smartAreaPassword',
    'smartAreaAutoSubmit',
    'smartAreaAutoImport',
    'smartAreaAutoLastRun',
    'smartAreaAutoLastResult',
    'smartAreaAutoNextRun',
    'smartAreaImportStatus'
  ], data => {
    document.getElementById('username').value = data.smartAreaUsername || '';
    document.getElementById('password').value = data.smartAreaPassword || '';
    document.getElementById('autoSubmit').checked = Boolean(data.smartAreaAutoSubmit);
    document.getElementById('autoImport').checked = Boolean(
      data.smartAreaAutoImport &&
      data.smartAreaAutoImport.enabled === true
    );
    renderStatus(data);
    loadImportPlan();
  });
}

function refreshRuntimeStatus() {
  chrome.storage.local.get([
    'smartAreaUsername',
    'smartAreaAutoImport',
    'smartAreaAutoLastRun',
    'smartAreaAutoLastResult',
    'smartAreaAutoNextRun',
    'smartAreaImportStatus'
  ], renderStatus);
}

function loadImportPlan() {
  chrome.runtime.sendMessage({ type: 'SMARTAREA_GET_IMPORT_PLAN' }, response => {
    const note = document.getElementById('importPlanNote');
    if (note) {
      const lookback = response && response.result ? Number(response.result.lookbackPages || 5) : 5;
      note.textContent = `อัปเดตล่าสุดจะตรวจ 3 หน้าล่าสุดเมื่อกดปุ่ม ส่วนตรวจย้อนหลังใช้เฉพาะซ่อมข้อมูล`;
    }
  });
}

document.getElementById('saveLogin').addEventListener('click', () => {
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;
  const autoSubmit = document.getElementById('autoSubmit').checked;
  const autoImport = document.getElementById('autoImport').checked;

  if (!username || !password) {
    setStatus('กรุณากรอกชื่อผู้ใช้และรหัสผ่านก่อน');
    return;
  }

  chrome.storage.local.set({
    smartAreaUsername: username,
    smartAreaPassword: password,
    smartAreaAutoSubmit: autoSubmit
  }, () => {
    const message = autoImport
      ? {
          type: 'SMARTAREA_AUTO_ENABLE',
          intervalMinutes: 60
        }
      : {
          type: 'SMARTAREA_AUTO_DISABLE'
        };

    chrome.runtime.sendMessage(message, response => {
      if (
        chrome.runtime.lastError ||
        (response && response.ok === false)
      ) {
        setStatus(
          (response && response.error) ||
          'บันทึกบัญชีแล้ว แต่ตั้งค่าการตรวจอัตโนมัติไม่สำเร็จ'
        );
        refreshRuntimeStatus();
        return;
      }

      setStatus(
        autoImport
          ? 'บันทึกบัญชีแล้ว ระบบจะตรวจใน 2 นาที และตรวจซ้ำทุก 1 ชั่วโมง'
          : 'บันทึกบัญชีแล้ว ปิดการตรวจอัตโนมัติ'
      );
      refreshRuntimeStatus();
    });
  });
});

document.getElementById('clearLogin').addEventListener('click', () => {
  chrome.storage.local.remove(['smartAreaUsername', 'smartAreaPassword', 'smartAreaAutoSubmit'], () => {
    chrome.runtime.sendMessage({ type: 'SMARTAREA_AUTO_DISABLE' }, () => {});
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
    document.getElementById('autoSubmit').checked = false;
    setStatus('ลบบัญชีที่บันทึกไว้แล้ว');
  });
});

document.getElementById('fillLogin').addEventListener('click', async () => {
  sendToSmartArea({ type: 'SMARTAREA_FILL_LOGIN' }, 'สั่งกรอกบัญชีแล้ว');
});

document.getElementById('checkNow').addEventListener('click', event => {
  setCheckButtonRunning(true);
  setStatus('กำลังตรวจ 3 หน้าล่าสุด กรุณารอสักครู่...');
  chrome.runtime.sendMessage(
    {
      type: 'SMARTAREA_CHECK_NOW',
      force: Boolean(event.shiftKey)
    },
    response => {
      if (chrome.runtime.lastError || !response || !response.ok) {
        setCheckButtonRunning(false);
        setStatus((response && response.error) || 'ตรวจหนังสือไม่สำเร็จ');
        return;
      }
      refreshRuntimeStatus();
    }
  );
});

document.getElementById('openWebApp').addEventListener('click', () => {
  chrome.tabs.create({ url: WEB_APP_URL });
});

// IMPORT_AREA_PMS_GUIDE_LINK_START
const installGuideLink = document.getElementById('installGuideLink');
if (installGuideLink) {
  installGuideLink.addEventListener('click', event => {
    event.preventDefault();
    chrome.tabs.create({ url: chrome.runtime.getURL('INSTALL-GUIDE.md') });
  });
}
// IMPORT_AREA_PMS_GUIDE_LINK_END

loadLoginSettings();
setInterval(refreshRuntimeStatus, 1000);


const fullSyncButton = document.getElementById('fullSync');
if (fullSyncButton) {
  fullSyncButton.addEventListener('click', () => {
    const confirmed = confirm(
      'ระบบจะตรวจหนังสือจากระบบกลางตั้งแต่หน้า 155 ถึงหน้าปัจจุบัน '
      + 'เทียบข้อมูลเดิม และนำเข้าเฉพาะรายการที่ยังไม่มี ขั้นตอนนี้อาจใช้เวลานาน ต้องการดำเนินการหรือไม่?'
    );
    if (!confirmed) return;

    fullSyncButton.disabled = true;
    setCheckButtonRunning(true);
    setStatus('กำลังตรวจย้อนหลังตั้งแต่หน้า 155 ถึงหน้าปัจจุบัน และตรวจความครบถ้วน...');

    chrome.runtime.sendMessage(
      {
        type: 'SMARTAREA_CHECK_NOW',
        startPage: 155,
        fullSync: true
      },
      response => {
        fullSyncButton.disabled = false;
        setCheckButtonRunning(false);

        if (chrome.runtime.lastError || !response || !response.ok) {
          setStatus((response && response.error) || 'ตรวจย้อนหลังไม่สำเร็จ');
          return;
        }

        refreshRuntimeStatus();
      }
    );
  });
}
