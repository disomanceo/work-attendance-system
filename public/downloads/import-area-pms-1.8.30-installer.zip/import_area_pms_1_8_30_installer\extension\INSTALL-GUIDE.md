# Import Area PMS 1.8.30

Install the extension with the included PowerShell script.

- Latest update scans the latest 3 pages only.
- Backfill scans from page 155 to the current latest page.
- Detail pages use `modules/book/main/bookdetail_school_saraban.php?b_id=...`.
- The import report shows the detail URL for failed rows.
