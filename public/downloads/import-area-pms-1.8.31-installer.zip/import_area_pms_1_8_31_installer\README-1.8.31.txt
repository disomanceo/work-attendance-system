Import Area PMS 1.8.31 installer. Install the extension, reload it in Chrome, and import from the Smart Area receive page.
