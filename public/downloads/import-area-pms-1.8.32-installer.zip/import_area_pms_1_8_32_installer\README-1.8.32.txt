Import Area PMS 1.8.32 installer. Install the extension, reload it in Chrome, and import from the Smart Area receive page.
